import { notifications as mantineNotifications } from '@mantine/notifications';

// Réexporter les notifications pour une utilisation cohérente
export const notifications = mantineNotifications;
